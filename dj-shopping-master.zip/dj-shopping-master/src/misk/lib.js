export default function on() {
    document.getElementById("overlay").style.display = "block";
}
  
export default function off() {
    document.getElementById("overlay").style.display = "none";
}