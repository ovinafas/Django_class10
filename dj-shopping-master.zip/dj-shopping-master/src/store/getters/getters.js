export default  {
  PRODUCTS(state) {
    return state.products;
  },
  CART(state) {
    return state.cart;
  }
}
